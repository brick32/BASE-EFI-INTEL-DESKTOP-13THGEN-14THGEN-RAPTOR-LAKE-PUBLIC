These files are only for macOS Sequoia
Files are updated for Sequoia 15.0 or higher