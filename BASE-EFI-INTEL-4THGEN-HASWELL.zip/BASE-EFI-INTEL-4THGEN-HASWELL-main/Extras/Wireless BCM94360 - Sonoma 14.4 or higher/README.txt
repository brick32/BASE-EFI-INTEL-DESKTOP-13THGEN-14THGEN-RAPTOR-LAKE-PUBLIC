These files are only for macOS Sonoma
Files are updated for Sonoma 14.4 or higher